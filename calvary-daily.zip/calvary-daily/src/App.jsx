import { useState, useEffect, useRef, useMemo } from "react";

// ─── M'Cheyne One-Year Bible Reading Plan (365 days, starting Jan 1) ─────────
// Each entry: [Family-Morning, Family-Evening, Personal-Morning, Personal-Evening]
const MCHEYNE = [
  ["Gen 1","Matt 1","Ezra 1","Acts 1"],["Gen 2","Matt 2","Ezra 2","Acts 2"],
  ["Gen 3","Matt 3","Ezra 3","Acts 3"],["Gen 4","Matt 4","Ezra 4","Acts 4"],
  ["Gen 5","Matt 5","Ezra 5","Acts 5"],["Gen 6","Matt 6","Ezra 6","Acts 6"],
  ["Gen 7","Matt 7","Ezra 7","Acts 7"],["Gen 8","Matt 8","Ezra 8","Acts 8"],
  ["Gen 9","Matt 9","Ezra 9","Acts 9"],["Gen 10","Matt 10","Ezra 10","Acts 10"],
  ["Gen 11","Matt 11","Neh 1","Acts 11"],["Gen 12","Matt 12","Neh 2","Acts 12"],
  ["Gen 13","Matt 13","Neh 3","Acts 13"],["Gen 14","Matt 14","Neh 4","Acts 14"],
  ["Gen 15","Matt 15","Neh 5","Acts 15"],["Gen 16","Matt 16","Neh 6","Acts 16"],
  ["Gen 17","Matt 17","Neh 7","Acts 17"],["Gen 18","Matt 18","Neh 8","Acts 18"],
  ["Gen 19","Matt 19","Neh 9","Acts 19"],["Gen 20","Matt 20","Neh 10","Acts 20"],
  ["Gen 21","Matt 21","Neh 11","Acts 21"],["Gen 22","Matt 22","Neh 12","Acts 22"],
  ["Gen 23","Matt 23","Neh 13","Acts 23"],["Gen 24","Matt 24","Est 1","Acts 24"],
  ["Gen 25","Matt 25","Est 2","Acts 25"],["Gen 26","Matt 26","Est 3","Acts 26"],
  ["Gen 27","Matt 27","Est 4","Acts 27"],["Gen 28","Matt 28","Est 5","Acts 28"],
  ["Gen 29","Mark 1","Est 6","Rom 1"],["Gen 30","Mark 2","Est 7","Rom 2"],
  ["Gen 31","Mark 3","Est 8","Rom 3"],
  // Feb
  ["Gen 32","Mark 4","Est 9–10","Rom 4"],["Gen 33","Mark 5","Job 1","Rom 5"],
  ["Gen 34","Mark 6","Job 2","Rom 6"],["Gen 35–36","Mark 7","Job 3","Rom 7"],
  ["Gen 37","Mark 8","Job 4","Rom 8"],["Gen 38","Mark 9","Job 5","Rom 9"],
  ["Gen 39","Mark 10","Job 6","Rom 10"],["Gen 40","Mark 11","Job 7","Rom 11"],
  ["Gen 41","Mark 12","Job 8","Rom 12"],["Gen 42","Mark 13","Job 9","Rom 13"],
  ["Gen 43","Mark 14","Job 10","Rom 14"],["Gen 44","Mark 15","Job 11","Rom 15"],
  ["Gen 45","Mark 16","Job 12","Rom 16"],["Gen 46","Luke 1","Job 13","1 Cor 1"],
  ["Gen 47","Luke 2","Job 14","1 Cor 2"],["Gen 48","Luke 3","Job 15","1 Cor 3"],
  ["Gen 49","Luke 4","Job 16–17","1 Cor 4"],["Gen 50","Luke 5","Job 18","1 Cor 5"],
  ["Ex 1","Luke 6","Job 19","1 Cor 6"],["Ex 2","Luke 7","Job 20","1 Cor 7"],
  ["Ex 3","Luke 8","Job 21","1 Cor 8"],["Ex 4","Luke 9","Job 22","1 Cor 9"],
  ["Ex 5","Luke 10","Job 23","1 Cor 10"],["Ex 6","Luke 11","Job 24","1 Cor 11"],
  ["Ex 7","Luke 12","Job 25–26","1 Cor 12"],["Ex 8","Luke 13","Job 27","1 Cor 13"],
  ["Ex 9","Luke 14","Job 28","1 Cor 14"],["Ex 10","Luke 15","Job 29","1 Cor 15"],
  // Mar
  ["Ex 11–12","Luke 16","Job 30","1 Cor 16"],["Ex 13","Luke 17","Job 31","2 Cor 1"],
  ["Ex 14","Luke 18","Job 32","2 Cor 2"],["Ex 15","Luke 19","Job 33","2 Cor 3"],
  ["Ex 16","Luke 20","Job 34","2 Cor 4"],["Ex 17","Luke 21","Job 35","2 Cor 5"],
  ["Ex 18","Luke 22","Job 36","2 Cor 6"],["Ex 19","Luke 23","Job 37","2 Cor 7"],
  ["Ex 20","Luke 24","Job 38","2 Cor 8"],["Ex 21","John 1","Job 39","2 Cor 9"],
  ["Ex 22","John 2","Job 40","2 Cor 10"],["Ex 23","John 3","Job 41","2 Cor 11"],
  ["Ex 24","John 4","Job 42","2 Cor 12"],["Ex 25","John 5","Prov 1","2 Cor 13"],
  ["Ex 26","John 6","Prov 2","Gal 1"],["Ex 27","John 7","Prov 3","Gal 2"],
  ["Ex 28","John 8","Prov 4","Gal 3"],["Ex 29","John 9","Prov 5","Gal 4"],
  ["Ex 30","John 10","Prov 6","Gal 5"],["Ex 31","John 11","Prov 7","Gal 6"],
  ["Ex 32","John 12","Prov 8","Eph 1"],["Ex 33","John 13","Prov 9","Eph 2"],
  ["Ex 34","John 14","Prov 10","Eph 3"],["Ex 35","John 15","Prov 11","Eph 4"],
  ["Ex 36","John 16","Prov 12","Eph 5"],["Ex 37","John 17","Prov 13","Eph 6"],
  ["Ex 38","John 18","Prov 14","Phil 1"],["Ex 39","John 19","Prov 15","Phil 2"],
  ["Ex 40","John 20","Prov 16","Phil 3"],["Lev 1","John 21","Prov 17","Phil 4"],
  ["Lev 2","Acts 1","Prov 18","Col 1"],
  // Apr
  ["Lev 3","Acts 2","Prov 19","Col 2"],["Lev 4","Acts 3","Prov 20","Col 3"],
  ["Lev 5","Acts 4","Prov 21","Col 4"],["Lev 6","Acts 5","Prov 22","1 Thess 1"],
  ["Lev 7","Acts 6","Prov 23","1 Thess 2"],["Lev 8","Acts 7","Prov 24","1 Thess 3"],
  ["Lev 9","Acts 8","Prov 25","1 Thess 4"],["Lev 10","Acts 9","Prov 26","1 Thess 5"],
  ["Lev 11–12","Acts 10","Prov 27","2 Thess 1"],["Lev 13","Acts 11","Prov 28","2 Thess 2"],
  ["Lev 14","Acts 12","Prov 29","2 Thess 3"],["Lev 15","Acts 13","Prov 30","1 Tim 1"],
  ["Lev 16","Acts 14","Prov 31","1 Tim 2"],["Lev 17","Acts 15","Eccl 1","1 Tim 3"],
  ["Lev 18","Acts 16","Eccl 2","1 Tim 4"],["Lev 19","Acts 17","Eccl 3","1 Tim 5"],
  ["Lev 20","Acts 18","Eccl 4","1 Tim 6"],["Lev 21","Acts 19","Eccl 5","2 Tim 1"],
  ["Lev 22","Acts 20","Eccl 6","2 Tim 2"],["Lev 23","Acts 21","Eccl 7","2 Tim 3"],
  ["Lev 24","Acts 22","Eccl 8","2 Tim 4"],["Lev 25","Acts 23","Eccl 9","Titus 1"],
  ["Lev 26","Acts 24","Eccl 10","Titus 2"],["Lev 27","Acts 25","Eccl 11","Titus 3"],
  ["Num 1","Acts 26","Eccl 12","Phlm"],["Num 2","Acts 27","Song 1","Heb 1"],
  ["Num 3","Acts 28","Song 2","Heb 2"],["Num 4","Rom 1","Song 3","Heb 3"],
  ["Num 5","Rom 2","Song 4","Heb 4"],["Num 6","Rom 3","Song 5","Heb 5"],
  // May
  ["Num 7","Rom 4","Song 6","Heb 6"],["Num 8","Rom 5","Song 7","Heb 7"],
  ["Num 9","Rom 6","Song 8","Heb 8"],["Num 10","Rom 7","Isa 1","Heb 9"],
  ["Num 11","Rom 8","Isa 2","Heb 10"],["Num 12–13","Rom 9","Isa 3–4","Heb 11"],
  ["Num 14","Rom 10","Isa 5","Heb 12"],["Num 15","Rom 11","Isa 6","Heb 13"],
  ["Num 16","Rom 12","Isa 7","James 1"],["Num 17–18","Rom 13","Isa 8","James 2"],
  ["Num 19","Rom 14","Isa 9","James 3"],["Num 20","Rom 15","Isa 10","James 4"],
  ["Num 21","Rom 16","Isa 11–12","James 5"],["Num 22","1 Cor 1","Isa 13","1 Pet 1"],
  ["Num 23","1 Cor 2","Isa 14","1 Pet 2"],["Num 24","1 Cor 3","Isa 15","1 Pet 3"],
  ["Num 25","1 Cor 4","Isa 16","1 Pet 4"],["Num 26","1 Cor 5","Isa 17–18","1 Pet 5"],
  ["Num 27","1 Cor 6","Isa 19–20","2 Pet 1"],["Num 28","1 Cor 7","Isa 21","2 Pet 2"],
  ["Num 29","1 Cor 8","Isa 22","2 Pet 3"],["Num 30","1 Cor 9","Isa 23","1 John 1"],
  ["Num 31","1 Cor 10","Isa 24","1 John 2"],["Num 32","1 Cor 11","Isa 25","1 John 3"],
  ["Num 33","1 Cor 12","Isa 26","1 John 4"],["Num 34","1 Cor 13","Isa 27","1 John 5"],
  ["Num 35","1 Cor 14","Isa 28","2 John"],["Num 36","1 Cor 15","Isa 29","3 John"],
  ["Deut 1","1 Cor 16","Isa 30","Jude"],["Deut 2","2 Cor 1","Isa 31","Rev 1"],
  ["Deut 3","2 Cor 2","Isa 32","Rev 2"],
  // Jun
  ["Deut 4","2 Cor 3","Isa 33","Rev 3"],["Deut 5","2 Cor 4","Isa 34","Rev 4"],
  ["Deut 6","2 Cor 5","Isa 35","Rev 5"],["Deut 7","2 Cor 6","Isa 36","Rev 6"],
  ["Deut 8","2 Cor 7","Isa 37","Rev 7"],["Deut 9","2 Cor 8","Isa 38","Rev 8"],
  ["Deut 10","2 Cor 9","Isa 39","Rev 9"],["Deut 11","2 Cor 10","Isa 40","Rev 10"],
  ["Deut 12","2 Cor 11","Isa 41","Rev 11"],["Deut 13–14","2 Cor 12","Isa 42","Rev 12"],
  ["Deut 15","2 Cor 13","Isa 43","Rev 13"],["Deut 16","Gal 1","Isa 44","Rev 14"],
  ["Deut 17","Gal 2","Isa 45","Rev 15"],["Deut 18","Gal 3","Isa 46","Rev 16"],
  ["Deut 19","Gal 4","Isa 47","Rev 17"],["Deut 20","Gal 5","Isa 48","Rev 18"],
  ["Deut 21","Gal 6","Isa 49","Rev 19"],["Deut 22","Eph 1","Isa 50","Rev 20"],
  ["Deut 23","Eph 2","Isa 51","Rev 21"],["Deut 24","Eph 3","Isa 52","Rev 22"],
  ["Deut 25","Eph 4","Isa 53","Matt 1"],["Deut 26","Eph 5","Isa 54","Matt 2"],
  ["Deut 27–28","Eph 6","Isa 55","Matt 3"],["Deut 29","Phil 1","Isa 56","Matt 4"],
  ["Deut 30","Phil 2","Isa 57","Matt 5"],["Deut 31","Phil 3","Isa 58","Matt 6"],
  ["Deut 32","Phil 4","Isa 59","Matt 7"],["Deut 33–34","Col 1","Isa 60","Matt 8"],
  ["Josh 1","Col 2","Isa 61","Matt 9"],["Josh 2","Col 3","Isa 62","Matt 10"],
  // Jul
  ["Josh 3","Col 4","Isa 63","Matt 11"],["Josh 4","1 Thess 1","Isa 64","Matt 12"],
  ["Josh 5–6","1 Thess 2","Isa 65","Matt 13"],["Josh 7","1 Thess 3","Isa 66","Matt 14"],
  ["Josh 8","1 Thess 4","Jer 1","Matt 15"],["Josh 9","1 Thess 5","Jer 2","Matt 16"],
  ["Josh 10","2 Thess 1","Jer 3","Matt 17"],["Josh 11","2 Thess 2","Jer 4","Matt 18"],
  ["Josh 12–13","2 Thess 3","Jer 5","Matt 19"],["Josh 14–15","1 Tim 1","Jer 6","Matt 20"],
  ["Josh 16–17","1 Tim 2","Jer 7","Matt 21"],["Josh 18–19","1 Tim 3","Jer 8","Matt 22"],
  ["Josh 20–21","1 Tim 4","Jer 9","Matt 23"],["Josh 22","1 Tim 5","Jer 10","Matt 24"],
  ["Josh 23","1 Tim 6","Jer 11","Matt 25"],["Josh 24","2 Tim 1","Jer 12","Matt 26"],
  ["Judg 1","2 Tim 2","Jer 13","Matt 27"],["Judg 2","2 Tim 3","Jer 14","Matt 28"],
  ["Judg 3","2 Tim 4","Jer 15","Mark 1"],["Judg 4","Titus 1","Jer 16","Mark 2"],
  ["Judg 5","Titus 2","Jer 17","Mark 3"],["Judg 6","Titus 3","Jer 18","Mark 4"],
  ["Judg 7","Phlm","Jer 19","Mark 5"],["Judg 8","Heb 1","Jer 20","Mark 6"],
  ["Judg 9","Heb 2","Jer 21","Mark 7"],["Judg 10–11","Heb 3","Jer 22","Mark 8"],
  ["Judg 12","Heb 4","Jer 23","Mark 9"],["Judg 13","Heb 5","Jer 24","Mark 10"],
  ["Judg 14","Heb 6","Jer 25","Mark 11"],["Judg 15","Heb 7","Jer 26","Mark 12"],
  ["Judg 16","Heb 8","Jer 27","Mark 13"],
  // Aug
  ["Judg 17","Heb 9","Jer 28","Mark 14"],["Judg 18","Heb 10","Jer 29","Mark 15"],
  ["Judg 19","Heb 11","Jer 30–31","Mark 16"],["Judg 20","Heb 12","Jer 32","Luke 1"],
  ["Judg 21","Heb 13","Jer 33","Luke 2"],["Ruth 1","James 1","Jer 34","Luke 3"],
  ["Ruth 2","James 2","Jer 35","Luke 4"],["Ruth 3–4","James 3","Jer 36","Luke 5"],
  ["1 Sam 1","James 4","Jer 37","Luke 6"],["1 Sam 2","James 5","Jer 38","Luke 7"],
  ["1 Sam 3","1 Pet 1","Jer 39","Luke 8"],["1 Sam 4","1 Pet 2","Jer 40","Luke 9"],
  ["1 Sam 5–6","1 Pet 3","Jer 41","Luke 10"],["1 Sam 7–8","1 Pet 4","Jer 42","Luke 11"],
  ["1 Sam 9","1 Pet 5","Jer 43","Luke 12"],["1 Sam 10","2 Pet 1","Jer 44","Luke 13"],
  ["1 Sam 11","2 Pet 2","Jer 45","Luke 14"],["1 Sam 12","2 Pet 3","Jer 46","Luke 15"],
  ["1 Sam 13","1 John 1","Jer 47","Luke 16"],["1 Sam 14","1 John 2","Jer 48","Luke 17"],
  ["1 Sam 15","1 John 3","Jer 49","Luke 18"],["1 Sam 16","1 John 4","Jer 50","Luke 19"],
  ["1 Sam 17","1 John 5","Jer 51","Luke 20"],["1 Sam 18","2 John","Jer 52","Luke 21"],
  ["1 Sam 19","3 John","Lam 1","Luke 22"],["1 Sam 20","Jude","Lam 2","Luke 23"],
  ["1 Sam 21–22","Rev 1","Lam 3","Luke 24"],["1 Sam 23","Rev 2","Lam 4","John 1"],
  ["1 Sam 24","Rev 3","Lam 5","John 2"],["1 Sam 25","Rev 4","Ezek 1","John 3"],
  ["1 Sam 26","Rev 5","Ezek 2","John 4"],
  // Sep
  ["1 Sam 27","Rev 6","Ezek 3","John 5"],["1 Sam 28","Rev 7","Ezek 4","John 6"],
  ["1 Sam 29–30","Rev 8","Ezek 5","John 7"],["1 Sam 31","Rev 9","Ezek 6","John 8"],
  ["2 Sam 1","Rev 10","Ezek 7","John 9"],["2 Sam 2","Rev 11","Ezek 8","John 10"],
  ["2 Sam 3","Rev 12","Ezek 9","John 11"],["2 Sam 4–5","Rev 13","Ezek 10","John 12"],
  ["2 Sam 6","Rev 14","Ezek 11","John 13"],["2 Sam 7","Rev 15","Ezek 12","John 14"],
  ["2 Sam 8–9","Rev 16","Ezek 13","John 15"],["2 Sam 10","Rev 17","Ezek 14","John 16"],
  ["2 Sam 11","Rev 18","Ezek 15","John 17"],["2 Sam 12","Rev 19","Ezek 16","John 18"],
  ["2 Sam 13","Rev 20","Ezek 17","John 19"],["2 Sam 14","Rev 21","Ezek 18","John 20"],
  ["2 Sam 15","Rev 22","Ezek 19","John 21"],["2 Sam 16","Matt 1","Ezek 20","Acts 1"],
  ["2 Sam 17","Matt 2","Ezek 21","Acts 2"],["2 Sam 18","Matt 3","Ezek 22","Acts 3"],
  ["2 Sam 19","Matt 4","Ezek 23","Acts 4"],["2 Sam 20","Matt 5","Ezek 24","Acts 5"],
  ["2 Sam 21","Matt 6","Ezek 25","Acts 6"],["2 Sam 22","Matt 7","Ezek 26","Acts 7"],
  ["2 Sam 23","Matt 8","Ezek 27","Acts 8"],["2 Sam 24","Matt 9","Ezek 28","Acts 9"],
  ["1 Kgs 1","Matt 10","Ezek 29","Acts 10"],["1 Kgs 2","Matt 11","Ezek 30","Acts 11"],
  ["1 Kgs 3","Matt 12","Ezek 31","Acts 12"],["1 Kgs 4–5","Matt 13","Ezek 32","Acts 13"],
  // Oct
  ["1 Kgs 6","Matt 14","Ezek 33","Acts 14"],["1 Kgs 7","Matt 15","Ezek 34","Acts 15"],
  ["1 Kgs 8","Matt 16","Ezek 35","Acts 16"],["1 Kgs 9","Matt 17","Ezek 36","Acts 17"],
  ["1 Kgs 10","Matt 18","Ezek 37","Acts 18"],["1 Kgs 11","Matt 19","Ezek 38","Acts 19"],
  ["1 Kgs 12","Matt 20","Ezek 39","Acts 20"],["1 Kgs 13","Matt 21","Ezek 40","Acts 21"],
  ["1 Kgs 14","Matt 22","Ezek 41","Acts 22"],["1 Kgs 15","Matt 23","Ezek 42","Acts 23"],
  ["1 Kgs 16","Matt 24","Ezek 43","Acts 24"],["1 Kgs 17","Matt 25","Ezek 44","Acts 25"],
  ["1 Kgs 18","Matt 26","Ezek 45","Acts 26"],["1 Kgs 19","Matt 27","Ezek 46","Acts 27"],
  ["1 Kgs 20","Matt 28","Ezek 47","Acts 28"],["1 Kgs 21","Mark 1","Ezek 48","Rom 1"],
  ["1 Kgs 22","Mark 2","Dan 1","Rom 2"],["2 Kgs 1","Mark 3","Dan 2","Rom 3"],
  ["2 Kgs 2","Mark 4","Dan 3","Rom 4"],["2 Kgs 3","Mark 5","Dan 4","Rom 5"],
  ["2 Kgs 4","Mark 6","Dan 5","Rom 6"],["2 Kgs 5","Mark 7","Dan 6","Rom 7"],
  ["2 Kgs 6","Mark 8","Dan 7","Rom 8"],["2 Kgs 7","Mark 9","Dan 8","Rom 9"],
  ["2 Kgs 8","Mark 10","Dan 9","Rom 10"],["2 Kgs 9","Mark 11","Dan 10","Rom 11"],
  ["2 Kgs 10","Mark 12","Dan 11","Rom 12"],["2 Kgs 11–12","Mark 13","Dan 12","Rom 13"],
  ["2 Kgs 13","Mark 14","Hos 1","Rom 14"],["2 Kgs 14","Mark 15","Hos 2","Rom 15"],
  ["2 Kgs 15","Mark 16","Hos 3","Rom 16"],
  // Nov
  ["2 Kgs 16","Luke 1","Hos 4","1 Cor 1"],["2 Kgs 17","Luke 2","Hos 5–6","1 Cor 2"],
  ["2 Kgs 18","Luke 3","Hos 7","1 Cor 3"],["2 Kgs 19","Luke 4","Hos 8","1 Cor 4"],
  ["2 Kgs 20","Luke 5","Hos 9","1 Cor 5"],["2 Kgs 21","Luke 6","Hos 10","1 Cor 6"],
  ["2 Kgs 22","Luke 7","Hos 11","1 Cor 7"],["2 Kgs 23","Luke 8","Hos 12","1 Cor 8"],
  ["2 Kgs 24","Luke 9","Hos 13","1 Cor 9"],["2 Kgs 25","Luke 10","Hos 14","1 Cor 10"],
  ["1 Chr 1–2","Luke 11","Joel 1","1 Cor 11"],["1 Chr 3–4","Luke 12","Joel 2","1 Cor 12"],
  ["1 Chr 5–6","Luke 13","Joel 3","1 Cor 13"],["1 Chr 7–8","Luke 14","Amos 1","1 Cor 14"],
  ["1 Chr 9–10","Luke 15","Amos 2","1 Cor 15"],["1 Chr 11–12","Luke 16","Amos 3","1 Cor 16"],
  ["1 Chr 13–14","Luke 17","Amos 4","2 Cor 1"],["1 Chr 15","Luke 18","Amos 5","2 Cor 2"],
  ["1 Chr 16","Luke 19","Amos 6","2 Cor 3"],["1 Chr 17","Luke 20","Amos 7","2 Cor 4"],
  ["1 Chr 18","Luke 21","Amos 8","2 Cor 5"],["1 Chr 19–20","Luke 22","Amos 9","2 Cor 6"],
  ["1 Chr 21","Luke 23","Obad","2 Cor 7"],["1 Chr 22","Luke 24","Jon 1","2 Cor 8"],
  ["1 Chr 23","John 1","Jon 2","2 Cor 9"],["1 Chr 24–25","John 2","Jon 3","2 Cor 10"],
  ["1 Chr 26–27","John 3","Jon 4","2 Cor 11"],["1 Chr 28","John 4","Mic 1","2 Cor 12"],
  ["1 Chr 29","John 5","Mic 2","2 Cor 13"],["2 Chr 1","John 6","Mic 3","Gal 1"],
  // Dec
  ["2 Chr 2","John 7","Mic 4","Gal 2"],["2 Chr 3–4","John 8","Mic 5","Gal 3"],
  ["2 Chr 5–6","John 9","Mic 6","Gal 4"],["2 Chr 7","John 10","Mic 7","Gal 5"],
  ["2 Chr 8","John 11","Nah 1","Gal 6"],["2 Chr 9","John 12","Nah 2","Eph 1"],
  ["2 Chr 10","John 13","Nah 3","Eph 2"],["2 Chr 11–12","John 14","Hab 1","Eph 3"],
  ["2 Chr 13","John 15","Hab 2","Eph 4"],["2 Chr 14–15","John 16","Hab 3","Eph 5"],
  ["2 Chr 16","John 17","Zeph 1","Eph 6"],["2 Chr 17","John 18","Zeph 2","Phil 1"],
  ["2 Chr 18","John 19","Zeph 3","Phil 2"],["2 Chr 19–20","John 20","Hag 1","Phil 3"],
  ["2 Chr 21","John 21","Hag 2","Phil 4"],["2 Chr 22–23","Acts 1","Zech 1","Col 1"],
  ["2 Chr 24","Acts 2","Zech 2","Col 2"],["2 Chr 25","Acts 3","Zech 3","Col 3"],
  ["2 Chr 26","Acts 4","Zech 4","Col 4"],["2 Chr 27–28","Acts 5","Zech 5","1 Thess 1"],
  ["2 Chr 29","Acts 6","Zech 6","1 Thess 2"],["2 Chr 30","Acts 7","Zech 7","1 Thess 3"],
  ["2 Chr 31","Acts 8","Zech 8","1 Thess 4"],["2 Chr 32","Acts 9","Zech 9","1 Thess 5"],
  ["2 Chr 33","Acts 10","Zech 10","2 Thess 1"],["2 Chr 34","Acts 11","Zech 11","2 Thess 2"],
  ["2 Chr 35","Acts 12","Zech 12–13","2 Thess 3"],["2 Chr 36","Acts 13","Zech 14","1 Tim 1"],
  ["Mal 1–2","Acts 14","Ps 1–2","1 Tim 2"],["Mal 3","Acts 15","Ps 3–4","1 Tim 3"],
  ["Mal 4","Acts 16","Ps 5","1 Tim 4"],
];

const COL_LABELS = ["Family · Morning","Family · Evening","Personal · Morning","Personal · Evening"];

function getDayOfYear(date) {
  const start = new Date(date.getFullYear(), 0, 0);
  return Math.floor((date - start) / 86400000) - 1; // 0-indexed
}

function formatDate(date) {
  return {
    weekday: date.toLocaleDateString("en-US", { weekday: "long" }),
    monthDay: date.toLocaleDateString("en-US", { month: "long", day: "numeric" }),
  };
}


// ─── Dark mode ────────────────────────────────────────────────────────────────
function useColorScheme() {
  const [dark, setDark] = useState(
    () => window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false
  );
  useEffect(() => {
    const mq = window.matchMedia?.("(prefers-color-scheme: dark)");
    if (!mq) return;
    const h = e => setDark(e.matches);
    mq.addEventListener("change", h);
    return () => mq.removeEventListener("change", h);
  }, []);
  return dark;
}

// ─── Theme ────────────────────────────────────────────────────────────────────
const LIGHT = {
  bg:"#F2F2F7", card:"#FFFFFF", text:"#1C1C1E", subtext:"#8E8E93",
  faint:"#3C3C43", sep:"#F2F2F7", border:"#E5E5EA",
  tabbar:"rgba(249,249,249,0.94)", tabbarBorder:"rgba(60,60,67,0.12)",
  btn:"#F2F2F7", btnText:"#3C3C43", handle:"#D1D1D6",
  sheet:"#FFFFFF", sheetSep:"#F2F2F7", accent:"#007AFF",
  green:"#34C759", orange:"#FF9500", red:"#FF3B30",
  unchecked:"#C7C7CC", shadow:"rgba(0,0,0,0.08)", inputBg:"#F2F2F7",
};
const DARK = {
  bg:"#000000", card:"#1C1C1E", text:"#FFFFFF", subtext:"#8E8E93",
  faint:"#EBEBF5", sep:"#38383A", border:"#38383A",
  tabbar:"rgba(18,18,18,0.94)", tabbarBorder:"rgba(255,255,255,0.1)",
  btn:"#2C2C2E", btnText:"#EBEBF5", handle:"#48484A",
  sheet:"#1C1C1E", sheetSep:"#38383A", accent:"#0A84FF",
  green:"#30D158", orange:"#FF9F0A", red:"#FF453A",
  unchecked:"#48484A", shadow:"rgba(0,0,0,0.4)", inputBg:"#2C2C2E",
};

// ─── Categories ───────────────────────────────────────────────────────────────
const CATEGORIES = [
  { id:"personal", label:"Personal", color:"#007AFF" },
  { id:"family",   label:"Family",   color:"#FF9500" },
  { id:"church",   label:"Church",   color:"#34C759" },
  { id:"work",     label:"Work",     color:"#AF52DE" },
  { id:"world",    label:"World",    color:"#FF3B30" },
  { id:"other",    label:"Other",    color:"#8E8E93" },
];
const catById = id => CATEGORIES.find(c => c.id === id) || CATEGORIES[5];

// ─── Helpers ──────────────────────────────────────────────────────────────────
const todayStr = () => new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"

function daysSince(dateStr) {
  if (!dateStr) return null;
  const diff = Math.floor((Date.now() - new Date(dateStr)) / 86400000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Yesterday";
  return `${diff}d ago`;
}

function calcStreak(prayers) {
  // Streak = consecutive days (ending today) on which ALL active prayers were prayed
  const active = prayers.filter(p => !p.answered);
  if (active.length === 0) return 0;
  let streak = 0;
  const d = new Date();
  while (true) {
    const ds = d.toISOString().slice(0, 10);
    const allPrayed = active.every(p => (p.prayedDates || []).includes(ds));
    if (!allPrayed) break;
    streak++;
    d.setDate(d.getDate() - 1);
  }
  return streak;
}

function dateFromDayIdx(idx, year) {
  const d = new Date(year, 0, 1);
  d.setDate(d.getDate() + idx);
  return d;
}

// ─── Bible fetch ──────────────────────────────────────────────────────────────
async function fetchPassage(reference) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 8096,
      messages: [{ role: "user", content:
        `Give me the complete KJV text of ${reference}. Format each verse exactly like this:\n1:1 In the beginning God created...\n1:2 And the earth was...\nEvery line must start with CHAPTER:VERSE then a space then the verse text. No headings, no blank lines, nothing else.`
      }]
    })
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  const raw = data.content?.[0]?.text?.trim() || "";
  const verses = [];
  for (const line of raw.split("\n")) {
    const m = line.match(/^(\d+):(\d+)\s+(.+)$/);
    if (m) verses.push({ chapter: parseInt(m[1]), verse: parseInt(m[2]), text: m[3] });
  }
  if (verses.length === 0) throw new Error("No verses parsed");
  return verses;
}

// ─── SVG Icons ────────────────────────────────────────────────────────────────
const Ic = ({ d, size=22, fill="none", sw=1.8 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
    {d.map((p,i) => p.startsWith("<") ? null : <path key={i} d={p}/>)}
    {d.filter(p=>p.startsWith("<polyline")).map((p,i)=>{
      const pts = p.match(/points="([^"]+)"/)?.[1];
      return pts ? <polyline key={i} points={pts}/> : null;
    })}
  </svg>
);
const BookIcon = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>;
const HeartIcon = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg>;
const HeartFill = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg>;
const CalIcon = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>;
const ChevR = ({size=16}) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg>;
const ChevL = ({size=18}) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>;
const XIcon = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>;
const PlusIcon = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;
const TrashIcon = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>;
const EditIcon = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>;
const CheckIcon = ({size=12, color="white"}) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>;
const PlayIcon = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="5 3 19 12 5 21 5 3"/></svg>;
const FolderIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>;
const NoteIcon = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>;

// ─── Spinner ──────────────────────────────────────────────────────────────────
function Spinner({ t }) {
  return (
    <div style={{ display:"flex", justifyContent:"center", padding:"40px 0" }}>
      <div style={{ width:28, height:28, borderRadius:"50%", border:`2.5px solid ${t.border}`, borderTopColor:t.accent, animation:"spin 0.8s linear infinite" }}/>
    </div>
  );
}

// ─── Reading Sheet ────────────────────────────────────────────────────────────
function ReadingSheet({ reading, onClose, t }) {
  const [verses, setVerses] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = () => {
    setLoading(true); setVerses(null); setError(false);
    fetchPassage(reading)
      .then(v => { setVerses(v); setLoading(false); })
      .catch(() => { setError(true); setLoading(false); });
  };
  useEffect(load, [reading]);

  const renderVerses = vs => {
    if (!vs?.length) return null;
    const chapters = [...new Set(vs.map(v => v.chapter))];
    return chapters.map(ch => (
      <div key={ch}>
        {chapters.length > 1 && (
          <p style={{ fontSize:"11px", fontWeight:700, color:t.accent, letterSpacing:"1px", textTransform:"uppercase", marginBottom:10, marginTop: ch===chapters[0]?0:20 }}>Chapter {ch}</p>
        )}
        {vs.filter(v=>v.chapter===ch).map((v,i) => (
          <p key={i} style={{ marginBottom:12, lineHeight:1.75, color:t.text }}>
            <span style={{ fontSize:"10px", fontWeight:700, color:t.accent, verticalAlign:"super", marginRight:4 }}>{v.verse}</span>
            {v.text}
          </p>
        ))}
      </div>
    ));
  };

  return (
    <div style={{ position:"fixed", inset:0, zIndex:200, display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
      <div onClick={onClose} style={{ position:"absolute", inset:0, background:"rgba(0,0,0,0.5)", animation:"fadeIn 0.2s ease" }}/>
      <div style={{ position:"relative", zIndex:1, background:t.sheet, borderRadius:"20px 20px 0 0", maxHeight:"88vh", display:"flex", flexDirection:"column", animation:"slideUp 0.3s cubic-bezier(0.32,0.72,0,1)", boxShadow:"0 -4px 40px rgba(0,0,0,0.3)", maxWidth:"390px", width:"100%", margin:"0 auto" }}>
        <div style={{ padding:"12px 20px 16px", borderBottom:`1px solid ${t.sheetSep}`, flexShrink:0 }}>
          <div style={{ width:36, height:4, borderRadius:2, background:t.handle, margin:"0 auto 16px" }}/>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
            <div>
              <p style={{ fontSize:"11px", color:t.subtext, letterSpacing:"0.5px", textTransform:"uppercase", fontWeight:600, marginBottom:3 }}>KJV</p>
              <h2 style={{ fontSize:"22px", fontWeight:700, color:t.text, letterSpacing:"-0.4px" }}>{reading}</h2>
            </div>
            <button onClick={onClose} style={{ width:32, height:32, borderRadius:"50%", background:t.btn, display:"flex", alignItems:"center", justifyContent:"center", color:t.btnText }}><XIcon/></button>
          </div>
        </div>
        <div style={{ overflowY:"auto", padding:"20px 24px 40px", flex:1 }}>
          {loading && <Spinner t={t}/>}
          {error && (
            <div style={{ textAlign:"center", padding:"40px 0" }}>
              <p style={{ color:t.subtext, fontSize:"15px", marginBottom:16 }}>Couldn't load passage.</p>
              <button onClick={load} style={{ background:t.accent, color:"#fff", borderRadius:10, padding:"10px 20px", fontSize:"14px", fontWeight:600 }}>Try Again</button>
            </div>
          )}
          {verses && <div style={{ fontFamily:"-apple-system, 'SF Pro Text', sans-serif", fontSize:"16px" }}>{renderVerses(verses)}</div>}
        </div>
      </div>
    </div>
  );
}

// ─── Prayer Stories Mode ──────────────────────────────────────────────────────
function PrayerStories({ prayers, onClose, onMarkPrayed, onMarkAnswered, t }) {
  const [idx, setIdx] = useState(0);
  const [exiting, setExiting] = useState(false);
  const active = prayers.filter(p => !p.answered);
  const todayS = todayStr();
  const done = active.length === 0;

  if (done) {
    return (
      <div style={{ position:"fixed", inset:0, zIndex:300, background:"#000", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center" }}>
        <div style={{ fontSize:56, marginBottom:20 }}>🙏</div>
        <p style={{ color:"#fff", fontSize:"24px", fontWeight:700, letterSpacing:"-0.4px" }}>All prayed!</p>
        <p style={{ color:"rgba(255,255,255,0.6)", fontSize:"15px", marginTop:8 }}>Great faithfulness today.</p>
        <button onClick={onClose} style={{ marginTop:32, background:"rgba(255,255,255,0.15)", color:"#fff", borderRadius:99, padding:"12px 28px", fontSize:"16px", fontWeight:600 }}>Done</button>
      </div>
    );
  }

  const current = active[idx] || active[0];
  const pct = ((idx) / active.length) * 100;
  const prayedToday = (current.prayedDates || []).includes(todayS);
  const cat = catById(current.category);

  const advance = () => {
    if (idx < active.length - 1) setIdx(i => i + 1);
    else onClose();
  };
  const retreat = () => { if (idx > 0) setIdx(i => i - 1); };

  const handlePrayed = () => {
    onMarkPrayed(current.id);
    setTimeout(advance, 350);
  };

  return (
    <div style={{ position:"fixed", inset:0, zIndex:300, background:"#111", display:"flex", flexDirection:"column", maxWidth:"390px", margin:"0 auto", left:0, right:0 }}>
      {/* Progress bars */}
      <div style={{ display:"flex", gap:4, padding:"52px 16px 12px", flexShrink:0 }}>
        {active.map((_, i) => (
          <div key={i} style={{ flex:1, height:3, borderRadius:99, background:"rgba(255,255,255,0.25)", overflow:"hidden" }}>
            <div style={{ height:"100%", borderRadius:99, background:"#fff", width: i < idx ? "100%" : i === idx ? "50%" : "0%" }}/>
          </div>
        ))}
      </div>

      {/* Header */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 16px 12px", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          <div style={{ width:10, height:10, borderRadius:"50%", background:cat.color }}/>
          <span style={{ color:"rgba(255,255,255,0.7)", fontSize:"12px", fontWeight:600, letterSpacing:"0.3px" }}>{cat.label.toUpperCase()}</span>
        </div>
        <button onClick={onClose} style={{ color:"rgba(255,255,255,0.6)", width:32, height:32, display:"flex", alignItems:"center", justifyContent:"center" }}><XIcon/></button>
      </div>

      {/* Tap zones (left/right) */}
      <div style={{ position:"absolute", left:0, top:0, width:"35%", height:"100%", zIndex:1 }} onClick={retreat}/>
      <div style={{ position:"absolute", right:0, top:0, width:"35%", height:"100%", zIndex:1 }} onClick={advance}/>

      {/* Card */}
      <div style={{ flex:1, display:"flex", flexDirection:"column", justifyContent:"center", padding:"0 28px 20px", zIndex:2, pointerEvents:"none" }}>
        <p style={{ color:cat.color, fontSize:"11px", fontWeight:700, letterSpacing:"1.5px", textTransform:"uppercase", marginBottom:16 }}>
          {idx + 1} of {active.length}
        </p>
        <h2 style={{ color:"#fff", fontSize:"28px", fontWeight:700, letterSpacing:"-0.5px", lineHeight:1.2, marginBottom:16 }}>
          {current.title}
        </h2>
        {current.description && (
          <p style={{ color:"rgba(255,255,255,0.7)", fontSize:"16px", lineHeight:1.6, marginBottom:16 }}>{current.description}</p>
        )}
        {current.note && (
          <div style={{ background:"rgba(255,255,255,0.08)", borderRadius:12, padding:"10px 14px", marginBottom:16 }}>
            <p style={{ color:"rgba(255,255,255,0.5)", fontSize:"10px", fontWeight:700, letterSpacing:"1px", marginBottom:4 }}>NOTE</p>
            <p style={{ color:"rgba(255,255,255,0.75)", fontSize:"14px", lineHeight:1.5 }}>{current.note}</p>
          </div>
        )}
        <p style={{ color:"rgba(255,255,255,0.4)", fontSize:"12px" }}>Added {current.date}</p>
      </div>

      {/* Actions */}
      <div style={{ padding:"16px 20px 48px", display:"flex", gap:12, flexShrink:0, zIndex:2 }}>
        <button
          onClick={handlePrayed}
          style={{
            flex:1, borderRadius:14, padding:"15px 0",
            background: prayedToday ? t.green : "rgba(255,255,255,0.15)",
            color:"#fff", fontSize:"15px", fontWeight:700,
            display:"flex", alignItems:"center", justifyContent:"center", gap:8,
            border: prayedToday ? `2px solid ${t.green}` : "2px solid transparent",
            pointerEvents:"all",
          }}
        >
          {prayedToday ? <><CheckIcon size={16}/> Prayed</> : "Mark as Prayed"}
        </button>
        <button
          onClick={() => { onMarkAnswered(current.id); advance(); }}
          style={{
            borderRadius:14, padding:"15px 18px",
            background:"rgba(255,255,255,0.08)", color:"rgba(255,255,255,0.7)",
            fontSize:"13px", fontWeight:600, pointerEvents:"all",
          }}
        >
          Answered ✓
        </button>
      </div>
    </div>
  );
}

// ─── Add / Edit Prayer Sheet ──────────────────────────────────────────────────
function PrayerFormSheet({ initial, onSave, onClose, t }) {
  const [title, setTitle] = useState(initial?.title || "");
  const [desc, setDesc]   = useState(initial?.description || "");
  const [note, setNote]   = useState(initial?.note || "");
  const [cat, setCat]     = useState(initial?.category || "personal");
  const isEdit = !!initial;

  const submit = () => {
    if (!title.trim()) return;
    onSave({ title: title.trim(), description: desc.trim(), note: note.trim(), category: cat });
    onClose();
  };

  return (
    <div style={{ position:"fixed", inset:0, zIndex:250, display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
      <div onClick={onClose} style={{ position:"absolute", inset:0, background:"rgba(0,0,0,0.5)" }}/>
      <div style={{ position:"relative", zIndex:1, background:t.sheet, borderRadius:"20px 20px 0 0", maxHeight:"90vh", display:"flex", flexDirection:"column", animation:"slideUp 0.3s cubic-bezier(0.32,0.72,0,1)", maxWidth:"390px", width:"100%", margin:"0 auto" }}>
        {/* Header */}
        <div style={{ padding:"12px 20px 16px", borderBottom:`1px solid ${t.sheetSep}`, flexShrink:0 }}>
          <div style={{ width:36, height:4, borderRadius:2, background:t.handle, margin:"0 auto 14px" }}/>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
            <h2 style={{ fontSize:"20px", fontWeight:700, color:t.text }}>{isEdit ? "Edit Request" : "New Request"}</h2>
            <button onClick={onClose} style={{ width:30, height:30, borderRadius:"50%", background:t.btn, display:"flex", alignItems:"center", justifyContent:"center", color:t.btnText }}><XIcon/></button>
          </div>
        </div>

        <div style={{ overflowY:"auto", flex:1, padding:"20px 20px 8px" }}>
          {/* Title */}
          <p style={{ fontSize:"11px", fontWeight:700, color:t.subtext, letterSpacing:"0.8px", textTransform:"uppercase", marginBottom:6 }}>Request *</p>
          <textarea
            autoFocus value={title} onChange={e=>setTitle(e.target.value)}
            placeholder="Who or what are you praying for?"
            style={{ width:"100%", background:t.inputBg, border:"none", borderRadius:10, padding:"12px 14px", fontSize:"16px", color:t.text, resize:"none", minHeight:72, lineHeight:1.5, marginBottom:16 }}
          />

          {/* Description */}
          <p style={{ fontSize:"11px", fontWeight:700, color:t.subtext, letterSpacing:"0.8px", textTransform:"uppercase", marginBottom:6 }}>Details (optional)</p>
          <textarea
            value={desc} onChange={e=>setDesc(e.target.value)}
            placeholder="Add context or specific details…"
            style={{ width:"100%", background:t.inputBg, border:"none", borderRadius:10, padding:"12px 14px", fontSize:"15px", color:t.text, resize:"none", minHeight:60, lineHeight:1.5, marginBottom:16 }}
          />

          {/* Note */}
          <p style={{ fontSize:"11px", fontWeight:700, color:t.subtext, letterSpacing:"0.8px", textTransform:"uppercase", marginBottom:6 }}>Prayer Note (optional)</p>
          <textarea
            value={note} onChange={e=>setNote(e.target.value)}
            placeholder="Updates, journal entries, how God is moving…"
            style={{ width:"100%", background:t.inputBg, border:"none", borderRadius:10, padding:"12px 14px", fontSize:"15px", color:t.text, resize:"none", minHeight:60, lineHeight:1.5, marginBottom:16 }}
          />

          {/* Category */}
          <p style={{ fontSize:"11px", fontWeight:700, color:t.subtext, letterSpacing:"0.8px", textTransform:"uppercase", marginBottom:8 }}>Category</p>
          <div style={{ display:"flex", flexWrap:"wrap", gap:8, marginBottom:24 }}>
            {CATEGORIES.map(c => (
              <button
                key={c.id}
                onClick={() => setCat(c.id)}
                style={{
                  borderRadius:99, padding:"6px 14px", fontSize:"13px", fontWeight:600,
                  background: cat===c.id ? c.color : t.btn,
                  color: cat===c.id ? "#fff" : t.subtext,
                  border:`2px solid ${cat===c.id ? c.color : "transparent"}`,
                  transition:"all 0.15s",
                }}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>

        <div style={{ padding:"8px 20px 40px", borderTop:`1px solid ${t.sheetSep}`, flexShrink:0 }}>
          <button
            onClick={submit}
            style={{ width:"100%", background:t.accent, color:"#fff", borderRadius:14, padding:"15px 0", fontSize:"16px", fontWeight:700 }}
          >
            {isEdit ? "Save Changes" : "Add Request"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Prayer Card ──────────────────────────────────────────────────────────────
function PrayerCard({ prayer, onPrayed, onAnswered, onEdit, onDelete, t }) {
  const [expanded, setExpanded] = useState(false);
  const todayS = todayStr();
  const prayedToday = (prayer.prayedDates || []).includes(todayS);
  const cat = catById(prayer.category);
  const lastPrayed = prayer.prayedDates?.length
    ? daysSince(prayer.prayedDates[prayer.prayedDates.length - 1])
    : null;

  return (
    <div style={{ background:t.card, borderRadius:16, overflow:"hidden", marginBottom:10 }}>
      <div style={{ display:"flex", alignItems:"flex-start", padding:"14px 14px 12px 16px" }}>
        {/* Prayed today circle */}
        <button
          onClick={() => onPrayed(prayer.id)}
          style={{
            width:28, height:28, borderRadius:"50%", flexShrink:0, marginRight:12, marginTop:2,
            background: prayedToday ? t.accent : "transparent",
            border:`2px solid ${prayedToday ? t.accent : t.unchecked}`,
            display:"flex", alignItems:"center", justifyContent:"center",
            transition:"all 0.2s cubic-bezier(0.34,1.56,0.64,1)",
          }}
        >
          {prayedToday && <CheckIcon/>}
        </button>

        <div style={{ flex:1, minWidth:0 }} onClick={() => setExpanded(e=>!e)}>
          <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:3 }}>
            <div style={{ width:8, height:8, borderRadius:"50%", background:cat.color, flexShrink:0 }}/>
            <span style={{ fontSize:"10px", fontWeight:700, color:t.subtext, letterSpacing:"0.5px", textTransform:"uppercase" }}>{cat.label}</span>
          </div>
          <p style={{ fontSize:"16px", fontWeight:600, color:t.text, lineHeight:1.35, marginBottom: prayer.description ? 4 : 0 }}>
            {prayer.title}
          </p>
          {prayer.description && (
            <p style={{ fontSize:"13px", color:t.subtext, lineHeight:1.4 }}>{prayer.description}</p>
          )}
          {lastPrayed && (
            <p style={{ fontSize:"11px", color:t.subtext, marginTop:5 }}>
              🙏 {lastPrayed} · {(prayer.prayedDates||[]).length} times total
            </p>
          )}
        </div>

        <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:6, marginLeft:8 }}>
          <button onClick={()=>setExpanded(e=>!e)} style={{ color:t.subtext, padding:2 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ transform: expanded?"rotate(180deg)":"rotate(0deg)", transition:"transform 0.2s" }}>
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </button>
        </div>
      </div>

      {expanded && (
        <div style={{ padding:"0 16px 14px", borderTop:`1px solid ${t.sep}`, paddingTop:12 }}>
          {prayer.note && (
            <div style={{ background:t.inputBg, borderRadius:10, padding:"10px 12px", marginBottom:10 }}>
              <p style={{ fontSize:"10px", fontWeight:700, color:t.subtext, letterSpacing:"0.8px", textTransform:"uppercase", marginBottom:4 }}>NOTE</p>
              <p style={{ fontSize:"14px", color:t.text, lineHeight:1.5 }}>{prayer.note}</p>
            </div>
          )}
          <div style={{ display:"flex", gap:8 }}>
            <button onClick={()=>onEdit(prayer)} style={{ flex:1, background:t.btn, borderRadius:10, padding:"9px 0", fontSize:"13px", fontWeight:600, color:t.subtext, display:"flex", alignItems:"center", justifyContent:"center", gap:5 }}>
              <EditIcon/> Edit
            </button>
            <button onClick={()=>onAnswered(prayer.id)} style={{ flex:1, background:"rgba(52,199,89,0.12)", borderRadius:10, padding:"9px 0", fontSize:"13px", fontWeight:600, color:t.green, display:"flex", alignItems:"center", justifyContent:"center", gap:5 }}>
              <CheckIcon size={13} color={t.green}/> Answered
            </button>
            <button onClick={()=>onDelete(prayer.id)} style={{ background:"rgba(255,59,48,0.1)", borderRadius:10, padding:"9px 12px", color:t.red, display:"flex", alignItems:"center", justifyContent:"center" }}>
              <TrashIcon/>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Calendar Tab ─────────────────────────────────────────────────────────────
function CalendarTab({ completedDays, prayedDays, todayIdx, onSelectDay, t }) {
  const year = new Date().getFullYear();
  const [calMonth, setCalMonth] = useState(new Date().getMonth());
  const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  const DOW = ["S","M","T","W","T","F","S"];
  const firstDay = new Date(year, calMonth, 1);
  const startDow = firstDay.getDay();
  const daysInMonth = new Date(year, calMonth+1, 0).getDate();
  function dayIdxForDate(d) { const s=new Date(year,0,0); return Math.floor((d-s)/86400000)-1; }
  const cells = [];
  for (let i=0;i<startDow;i++) cells.push(null);
  for (let d=1;d<=daysInMonth;d++) cells.push({ day:d, idx:dayIdxForDate(new Date(year,calMonth,d)) });

  const readPct  = Math.round((completedDays.size / 365) * 100);
  const prayPct  = Math.round((prayedDays.size   / 365) * 100);

  // Days in this month that are past or today
  const pastDaysInMonth = cells.filter(c => c && c.idx <= todayIdx).length;
  const monthReadDone  = cells.filter(c => c && completedDays.has(c.idx)).length;
  const monthPrayDone  = cells.filter(c => c && prayedDays.has(c.idx)).length;

  return (
    <div>
      {/* Dual progress cards */}
      <div style={{ display:"flex", gap:10, marginBottom:16 }}>
        {[
          { label:"Reading", done:completedDays.size, pct:readPct, color:t.accent },
          { label:"Prayer",  done:prayedDays.size,    pct:prayPct, color:t.green  },
        ].map(({ label, done, pct, color }) => (
          <div key={label} style={{ flex:1, background:t.card, borderRadius:14, padding:"14px 14px 12px" }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
              <p style={{ fontSize:"12px", fontWeight:600, color:t.subtext }}>{label}</p>
              <p style={{ fontSize:"13px", fontWeight:700, color }}>{pct}%</p>
            </div>
            <div style={{ background:t.border, borderRadius:99, height:5 }}>
              <div style={{ background:color, borderRadius:99, height:5, width:`${pct}%`, transition:"width 0.5s" }}/>
            </div>
            <p style={{ fontSize:"11px", color:t.subtext, marginTop:6 }}>{done} / 365 days</p>
          </div>
        ))}
      </div>

      {/* Month nav */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 4px", marginBottom:10 }}>
        <button onClick={()=>setCalMonth(m=>Math.max(0,m-1))} disabled={calMonth===0}
          style={{ width:34, height:34, borderRadius:"50%", background:calMonth===0?"transparent":t.card, display:"flex", alignItems:"center", justifyContent:"center", color:calMonth===0?t.unchecked:t.accent }}>
          <ChevL/>
        </button>
        <div style={{ textAlign:"center" }}>
          <p style={{ fontSize:"17px", fontWeight:700, color:t.text, letterSpacing:"-0.3px" }}>{MONTHS[calMonth]} {year}</p>
          {pastDaysInMonth > 0 && (
            <p style={{ fontSize:"11px", color:t.subtext, marginTop:1 }}>
              📖 {monthReadDone}/{pastDaysInMonth} &nbsp;·&nbsp; 🙏 {monthPrayDone}/{pastDaysInMonth}
            </p>
          )}
        </div>
        <button onClick={()=>setCalMonth(m=>Math.min(11,m+1))} disabled={calMonth===11}
          style={{ width:34, height:34, borderRadius:"50%", background:calMonth===11?"transparent":t.card, display:"flex", alignItems:"center", justifyContent:"center", color:calMonth===11?t.unchecked:t.accent }}>
          <ChevR size={18}/>
        </button>
      </div>

      {/* Grid */}
      <div style={{ background:t.card, borderRadius:16, padding:"12px 8px 16px" }}>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)", marginBottom:4 }}>
          {DOW.map((d,i)=><div key={i} style={{ textAlign:"center", fontSize:"11px", fontWeight:700, color:t.subtext, padding:"4px 0" }}>{d}</div>)}
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)", gap:"2px" }}>
          {cells.map((cell,i)=>{
            if (!cell) return <div key={i}/>;
            const isToday  = cell.idx === todayIdx;
            const isFuture = cell.idx > todayIdx;
            const didRead  = completedDays.has(cell.idx);
            const didPray  = prayedDays.has(cell.idx);
            const both     = didRead && didPray;

            // Cell bg: both=accent, today=subtle, else transparent
            const cellBg   = both ? t.accent : isToday ? t.btn : "transparent";
            const numColor = both ? "#fff" : isToday ? t.accent : isFuture ? t.unchecked : t.text;

            return (
              <button
                key={i}
                onClick={()=>!isFuture&&cell.idx>=0&&cell.idx<365&&onSelectDay(cell.idx)}
                style={{
                  borderRadius:10, padding:"5px 2px 4px",
                  display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center",
                  background: cellBg,
                  border: isToday && !both ? `2px solid ${t.accent}` : "2px solid transparent",
                  cursor: isFuture ? "default" : "pointer",
                  minWidth:0,
                }}
              >
                <span style={{ fontSize:"13px", fontWeight:isToday?700:400, color:numColor, lineHeight:1.2 }}>
                  {cell.day}
                </span>
                {/* Indicator dots — only show for past/today */}
                {!isFuture && (
                  <div style={{ display:"flex", gap:2, marginTop:3, height:5, alignItems:"center" }}>
                    {/* Reading dot */}
                    <div style={{ width:4, height:4, borderRadius:"50%", background: didRead ? (both ? "rgba(255,255,255,0.8)" : t.accent) : t.unchecked, flexShrink:0 }}/>
                    {/* Prayer dot */}
                    <div style={{ width:4, height:4, borderRadius:"50%", background: didPray ? (both ? "rgba(255,255,255,0.8)" : t.green) : t.unchecked, flexShrink:0 }}/>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Legend */}
      <div style={{ display:"flex", gap:14, padding:"12px 4px 0", justifyContent:"center", flexWrap:"wrap" }}>
        {[
          { color:t.accent, label:"Reading done" },
          { color:t.green,  label:"Prayer done"  },
          { color:t.accent, label:"Both done", border:true },
        ].map(({ color, label, border }, i) => (
          <div key={i} style={{ display:"flex", alignItems:"center", gap:5 }}>
            {border ? (
              <div style={{ width:14, height:14, borderRadius:4, background:t.accent, display:"flex", alignItems:"center", justifyContent:"center" }}>
                <div style={{ display:"flex", gap:1 }}>
                  <div style={{ width:3, height:3, borderRadius:"50%", background:"rgba(255,255,255,0.8)" }}/>
                  <div style={{ width:3, height:3, borderRadius:"50%", background:"rgba(255,255,255,0.8)" }}/>
                </div>
              </div>
            ) : (
              <div style={{ width:6, height:6, borderRadius:"50%", background:color }}/>
            )}
            <span style={{ fontSize:"11px", color:t.subtext }}>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main App ────────────────────────────────────────────────────────────────
export default function App() {
  const dark = useColorScheme();
  const t = dark ? DARK : LIGHT;

  const today = new Date();
  const todayIdx = Math.min(getDayOfYear(today), MCHEYNE.length-1);
  const year = today.getFullYear();

  const [tab, setTab] = useState("today");
  const [viewDayIdx, setViewDayIdx] = useState(todayIdx);
  const [checked, setChecked] = useState(new Set());
  const [completedDays, setCompletedDays] = useState(new Set());
  const [prayers, setPrayers] = useState([]);
  const [openReading, setOpenReading] = useState(null);
  const [storiesOpen, setStoriesOpen] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editPrayer, setEditPrayer] = useState(null);
  const [showAnswered, setShowAnswered] = useState(false);

  const viewDate = dateFromDayIdx(viewDayIdx, year);
  const { weekday, monthDay } = formatDate(viewDate);
  const readings = MCHEYNE[viewDayIdx] || MCHEYNE[0];
  const isToday = viewDayIdx === todayIdx;

  // Load checked for viewDay
  useEffect(() => {
    try { const r=localStorage.getItem(`checked:${year}-${viewDayIdx}`); setChecked(r?new Set(JSON.parse(r)):new Set()); }
    catch(_){setChecked(new Set());}
  }, [viewDayIdx]);

  // Load prayers + completed days on mount
  useEffect(() => {
    try { const p=localStorage.getItem("prayers-v2"); if(p) setPrayers(JSON.parse(p)); } catch(_){}
    try {
      const prefix = `checked:${year}-`;
      const done=new Set();
      for(let i=0;i<localStorage.length;i++){
        const key=localStorage.key(i);
        if(key&&key.startsWith(prefix)){
          try{ const a=JSON.parse(localStorage.getItem(key)||"[]");if(a.length===4){const idx=parseInt(key.split("-").pop());if(!isNaN(idx))done.add(idx);}}catch(_){}
        }
      }
      setCompletedDays(done);
    } catch(_){}
  }, []);

  const savePrayers = list => {
    setPrayers(list);
    try { localStorage.setItem("prayers-v2", JSON.stringify(list)); } catch(_){}
  };

  const toggleCheck = i => {
    const next = new Set(checked);
    next.has(i)?next.delete(i):next.add(i);
    setChecked(next);
    try { localStorage.setItem(`checked:${year}-${viewDayIdx}`, JSON.stringify([...next])); } catch(_){}
    if(next.size===4) setCompletedDays(prev=>new Set([...prev,viewDayIdx]));
    else setCompletedDays(prev=>{const s=new Set(prev);s.delete(viewDayIdx);return s;});
  };

  const addOrEditPrayer = ({ title, description, note, category }) => {
    if (editPrayer) {
      savePrayers(prayers.map(p => p.id===editPrayer.id ? {...p, title, description, note, category} : p));
      setEditPrayer(null);
    } else {
      savePrayers([...prayers, {
        id: Date.now(), title, description, note, category,
        answered: false, prayedDates: [],
        date: today.toLocaleDateString("en-US",{month:"short",day:"numeric"}),
        answeredDate: null,
      }]);
    }
  };

  const markPrayed = id => {
    const todayS = todayStr();
    savePrayers(prayers.map(p => {
      if(p.id!==id) return p;
      const dates = p.prayedDates||[];
      const already = dates.includes(todayS);
      return { ...p, prayedDates: already ? dates.filter(d=>d!==todayS) : [...dates, todayS] };
    }));
  };

  const markAnswered = id => {
    savePrayers(prayers.map(p => p.id===id ? {...p, answered:true, answeredDate:todayStr()} : p));
  };

  const deletePrayer = id => savePrayers(prayers.filter(p=>p.id!==id));

  const activePrayers   = prayers.filter(p=>!p.answered);
  const answeredPrayers = prayers.filter(p=>p.answered);
  const prayedTodayCount = activePrayers.filter(p=>(p.prayedDates||[]).includes(todayStr())).length;
  const streak = calcStreak(prayers);
  const allPrayedToday = activePrayers.length>0 && prayedTodayCount===activePrayers.length;
  const doneCount = checked.size;
  const allDone = doneCount===4;

  // Build prayedDays: Set of dayIdx where ALL active (non-answered) prayers were prayed
  // We collect every date that appears across all prayers, then keep only dates where
  // every active prayer was prayed.
  const prayedDays = useMemo(() => {
    const allActive = prayers.filter(p => !p.answered);
    if (allActive.length === 0) return new Set();
    // Gather all unique dates across all active prayers
    const allDates = new Set(allActive.flatMap(p => p.prayedDates || []));
    const result = new Set();
    for (const dateStr of allDates) {
      if (allActive.every(p => (p.prayedDates || []).includes(dateStr))) {
        // Convert YYYY-MM-DD to day index
        const d = new Date(dateStr + "T00:00:00");
        const start = new Date(year, 0, 0);
        const idx = Math.floor((d - start) / 86400000) - 1;
        if (idx >= 0 && idx < 365) result.add(idx);
      }
    }
    return result;
  }, [prayers, year]);

  return (
    <div style={{ fontFamily:"-apple-system,'SF Pro Display',sans-serif", background:t.bg, minHeight:"100vh", maxWidth:"390px", margin:"0 auto", position:"relative", overflowX:"hidden", colorScheme:dark?"dark":"light" }}>
      <style>{`
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes fadeIn{from{opacity:0}to{opacity:1}}
        @keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
        @keyframes pop{0%{transform:scale(1)}40%{transform:scale(1.18)}100%{transform:scale(1)}}
        *{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
        ::-webkit-scrollbar{display:none}
        button{background:none;border:none;cursor:pointer;font-family:inherit}
        textarea{font-family:inherit}
        textarea:focus,input:focus{outline:none}
        .check-pop{animation:pop 0.25s cubic-bezier(0.34,1.56,0.64,1)}
        .row-tap:active{opacity:0.6}
        .nav-btn:active{opacity:0.5}
      `}</style>

      <div style={{ height:50 }}/>

      {/* ── HEADER ── */}
      <div style={{ padding:"0 20px 20px" }}>
        {tab==="today" ? (
          <>
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:4 }}>
              <button className="nav-btn" onClick={()=>setViewDayIdx(i=>Math.max(0,i-1))} disabled={viewDayIdx===0}
                style={{ width:34,height:34,borderRadius:"50%",background:viewDayIdx===0?"transparent":t.card,display:"flex",alignItems:"center",justifyContent:"center",color:viewDayIdx===0?t.unchecked:t.accent }}>
                <ChevL/>
              </button>
              <div style={{ textAlign:"center", flex:1 }}>
                <p style={{ fontSize:"13px",color:t.subtext,fontWeight:500 }}>{isToday?"Today":weekday}</p>
                <h1 style={{ fontSize:"28px",fontWeight:700,color:t.text,letterSpacing:"-0.6px",lineHeight:1.15 }}>{monthDay}</h1>
              </div>
              <button className="nav-btn" onClick={()=>setViewDayIdx(i=>Math.min(todayIdx,i+1))} disabled={viewDayIdx>=todayIdx}
                style={{ width:34,height:34,borderRadius:"50%",background:viewDayIdx>=todayIdx?"transparent":t.card,display:"flex",alignItems:"center",justifyContent:"center",color:viewDayIdx>=todayIdx?t.unchecked:t.accent }}>
                <ChevR size={18}/>
              </button>
            </div>
            {!isToday && <div style={{ textAlign:"center",marginTop:6 }}><button onClick={()=>setViewDayIdx(todayIdx)} style={{ background:t.accent,color:"#fff",borderRadius:99,padding:"4px 14px",fontSize:"12px",fontWeight:600 }}>Jump to Today</button></div>}
            <div style={{ marginTop:12,display:"flex",alignItems:"center",justifyContent:"center",gap:10 }}>
              <div style={{ display:"flex",gap:5 }}>
                {[0,1,2,3].map(i=><div key={i} style={{ width:8,height:8,borderRadius:"50%",background:checked.has(i)?t.accent:t.unchecked,transition:"background 0.25s" }}/>)}
              </div>
              <p style={{ fontSize:"13px",color:t.subtext,fontWeight:500 }}>{allDone?"Complete ✓":`${doneCount} of 4`}</p>
            </div>
          </>
        ) : tab==="prayer" ? (
          <>
            <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between" }}>
              <div>
                <p style={{ fontSize:"15px",color:t.subtext,fontWeight:500,marginBottom:2 }}>Daily</p>
                <h1 style={{ fontSize:"34px",fontWeight:700,color:t.text,letterSpacing:"-0.8px",lineHeight:1.1 }}>Prayer List</h1>
              </div>
              {streak>0 && (
                <div style={{ background:t.card,borderRadius:12,padding:"8px 12px",textAlign:"center",marginTop:4 }}>
                  <p style={{ fontSize:"20px",lineHeight:1 }}>🔥</p>
                  <p style={{ fontSize:"13px",fontWeight:700,color:t.text }}>{streak}</p>
                  <p style={{ fontSize:"10px",color:t.subtext }}>day streak</p>
                </div>
              )}
            </div>
            <p style={{ fontSize:"13px",color:t.subtext,fontWeight:500,marginTop:6 }}>
              {activePrayers.length} active · {prayedTodayCount}/{activePrayers.length} prayed today · {answeredPrayers.length} answered
            </p>
          </>
        ) : (
          <>
            <p style={{ fontSize:"15px",color:t.subtext,fontWeight:500,marginBottom:2 }}>M'Cheyne Plan</p>
            <h1 style={{ fontSize:"34px",fontWeight:700,color:t.text,letterSpacing:"-0.8px",lineHeight:1.1 }}>{year} Calendar</h1>
          </>
        )}
      </div>

      {/* ── CONTENT ── */}
      <div style={{ overflowY:"auto", padding:"0 16px 100px" }}>

        {/* TODAY */}
        {tab==="today" && (
          <div>
            <p style={{ fontSize:"11px",fontWeight:700,color:t.subtext,letterSpacing:"0.8px",textTransform:"uppercase",padding:"0 4px",marginBottom:8 }}>
              M'Cheyne Reading Plan · Day {viewDayIdx+1}
            </p>
            <div style={{ background:t.card,borderRadius:16,overflow:"hidden" }}>
              {readings.map((ref,i)=>(
                <div key={i}>
                  {i>0&&<div style={{ height:1,background:t.sep,marginLeft:56 }}/>}
                  <div className="row-tap" style={{ display:"flex",alignItems:"center",padding:"14px 16px" }}>
                    <button onClick={()=>toggleCheck(i)} className={checked.has(i)?"check-pop":""} style={{ width:26,height:26,borderRadius:"50%",flexShrink:0,marginRight:14,background:checked.has(i)?t.accent:"transparent",border:`2px solid ${checked.has(i)?t.accent:t.unchecked}`,display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.2s cubic-bezier(0.34,1.56,0.64,1)" }}>
                      {checked.has(i)&&<CheckIcon/>}
                    </button>
                    <div style={{ flex:1,minWidth:0 }} onClick={()=>setOpenReading(ref)}>
                      <p style={{ fontSize:"11px",color:t.subtext,fontWeight:600,letterSpacing:"0.3px",marginBottom:2 }}>{COL_LABELS[i]}</p>
                      <p style={{ fontSize:"17px",fontWeight:600,letterSpacing:"-0.2px",textDecoration:checked.has(i)?"line-through":"none",color:checked.has(i)?t.subtext:t.text,transition:"color 0.2s" }}>{ref}</p>
                    </div>
                    <button onClick={()=>setOpenReading(ref)} style={{ width:32,height:32,borderRadius:"50%",background:t.btn,display:"flex",alignItems:"center",justifyContent:"center",color:t.accent,flexShrink:0,marginLeft:8 }}>
                      <ChevR/>
                    </button>
                  </div>
                </div>
              ))}
            </div>
            {allDone&&(
              <div style={{ marginTop:16,background:t.accent,borderRadius:14,padding:"16px 20px",textAlign:"center",animation:"fadeIn 0.4s ease" }}>
                <p style={{ fontSize:"17px",fontWeight:700,color:"#fff",letterSpacing:"-0.2px" }}>Reading complete! ✓</p>
                <p style={{ fontSize:"13px",color:"rgba(255,255,255,0.8)",marginTop:3 }}>{isToday?"Well done — keep pressing on.":"This day is fully complete."}</p>
              </div>
            )}
          </div>
        )}

        {/* CALENDAR */}
        {tab==="calendar" && (
          <CalendarTab completedDays={completedDays} prayedDays={prayedDays} todayIdx={todayIdx} onSelectDay={idx=>{setViewDayIdx(idx);setTab("today");}} t={t}/>
        )}

        {/* PRAYER */}
        {tab==="prayer" && (
          <div>
            {/* Start Stories + Add buttons */}
            <div style={{ display:"flex", gap:10, marginBottom:16 }}>
              {activePrayers.length>0&&(
                <button
                  onClick={()=>setStoriesOpen(true)}
                  style={{ flex:2,background:t.accent,borderRadius:14,padding:"14px 0",display:"flex",alignItems:"center",justifyContent:"center",gap:8,color:"#fff",fontSize:"15px",fontWeight:700 }}
                >
                  <PlayIcon/> Pray Through List
                </button>
              )}
              <button
                onClick={()=>setShowForm(true)}
                style={{ flex:1,background:t.card,borderRadius:14,padding:"14px 0",display:"flex",alignItems:"center",justifyContent:"center",gap:6,color:t.accent,fontSize:"15px",fontWeight:600,border:`1.5px dashed ${t.unchecked}` }}
              >
                <PlusIcon/> Add
              </button>
            </div>

            {/* All prayed banner */}
            {allPrayedToday&&(
              <div style={{ background:"rgba(52,199,89,0.12)",border:`1px solid ${t.green}`,borderRadius:14,padding:"12px 16px",marginBottom:16,display:"flex",alignItems:"center",gap:10,animation:"fadeIn 0.3s ease" }}>
                <span style={{ fontSize:20 }}>🙌</span>
                <div>
                  <p style={{ fontSize:"14px",fontWeight:700,color:t.green }}>All prayed today!</p>
                  <p style={{ fontSize:"12px",color:t.subtext }}>Great faithfulness. Keep it up.</p>
                </div>
              </div>
            )}

            {/* Active prayers */}
            {activePrayers.length>0 && (
              <>
                <p style={{ fontSize:"11px",fontWeight:700,color:t.subtext,letterSpacing:"0.8px",textTransform:"uppercase",padding:"0 4px",marginBottom:10 }}>
                  Active Requests
                </p>
                {activePrayers.map(p=>(
                  <PrayerCard key={p.id} prayer={p} onPrayed={markPrayed} onAnswered={markAnswered} onEdit={p=>{setEditPrayer(p);setShowForm(true);}} onDelete={deletePrayer} t={t}/>
                ))}
              </>
            )}

            {activePrayers.length===0&&!showForm&&(
              <div style={{ textAlign:"center",padding:"40px 0" }}>
                <div style={{ opacity:0.3,marginBottom:12,display:"flex",justifyContent:"center" }}><HeartIcon/></div>
                <p style={{ fontSize:"17px",fontWeight:600,color:t.faint }}>No active requests</p>
                <p style={{ fontSize:"14px",color:t.subtext,marginTop:4 }}>Tap Add to get started</p>
              </div>
            )}

            {/* Answered folder */}
            {answeredPrayers.length>0&&(
              <div style={{ marginTop:8 }}>
                <button
                  onClick={()=>setShowAnswered(a=>!a)}
                  style={{ width:"100%",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 4px",color:t.subtext }}
                >
                  <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                    <FolderIcon/>
                    <span style={{ fontSize:"13px",fontWeight:600 }}>Answered Prayers ({answeredPrayers.length})</span>
                  </div>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ transform:showAnswered?"rotate(180deg)":"rotate(0deg)",transition:"transform 0.2s" }}><polyline points="6 9 12 15 18 9"/></svg>
                </button>

                {showAnswered&&(
                  <div style={{ marginTop:6 }}>
                    {answeredPrayers.map(p=>(
                      <div key={p.id} style={{ background:t.card,borderRadius:14,padding:"12px 16px",marginBottom:8,display:"flex",alignItems:"flex-start",gap:12 }}>
                        <div style={{ width:28,height:28,borderRadius:"50%",flexShrink:0,background:t.green,border:`2px solid ${t.green}`,display:"flex",alignItems:"center",justifyContent:"center",marginTop:2 }}>
                          <CheckIcon size={12}/>
                        </div>
                        <div style={{ flex:1 }}>
                          <p style={{ fontSize:"15px",fontWeight:600,color:t.subtext,textDecoration:"line-through",lineHeight:1.3 }}>{p.title}</p>
                          {p.description&&<p style={{ fontSize:"13px",color:t.subtext,marginTop:3,textDecoration:"line-through" }}>{p.description}</p>}
                          <p style={{ fontSize:"11px",color:t.subtext,marginTop:5 }}>
                            ✓ Answered {p.answeredDate||p.date} · prayed {(p.prayedDates||[]).length} times
                          </p>
                        </div>
                        <button onClick={()=>deletePrayer(p.id)} style={{ color:t.unchecked,padding:4 }}><TrashIcon/></button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── TAB BAR ── */}
      <div style={{ position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:"390px",background:t.tabbar,backdropFilter:"blur(20px) saturate(180%)",WebkitBackdropFilter:"blur(20px) saturate(180%)",borderTop:`0.5px solid ${t.tabbarBorder}`,display:"flex",padding:"10px 0 28px",zIndex:100 }}>
        {[
          { id:"today",    label:"Today",    Icon:BookIcon },
          { id:"calendar", label:"Calendar", Icon:CalIcon },
          { id:"prayer",   label:"Prayer",   Icon:tab==="prayer"?HeartFill:HeartIcon },
        ].map(({id,label,Icon})=>(
          <button key={id} onClick={()=>setTab(id)} style={{ flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:3,color:tab===id?t.accent:t.subtext,transition:"color 0.2s" }}>
            <Icon/>
            <span style={{ fontSize:"10px",fontWeight:tab===id?700:400,letterSpacing:"0.2px" }}>{label}</span>
          </button>
        ))}
      </div>

      {/* ── OVERLAYS ── */}
      {openReading&&<ReadingSheet reading={openReading} onClose={()=>setOpenReading(null)} t={t}/>}

      {storiesOpen&&(
        <PrayerStories
          prayers={activePrayers}
          onClose={()=>setStoriesOpen(false)}
          onMarkPrayed={markPrayed}
          onMarkAnswered={markAnswered}
          t={t}
        />
      )}

      {showForm&&(
        <PrayerFormSheet
          initial={editPrayer}
          onSave={addOrEditPrayer}
          onClose={()=>{setShowForm(false);setEditPrayer(null);}}
          t={t}
        />
      )}
    </div>
  );
}
