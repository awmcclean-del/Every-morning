# Daily Discipleship App
M'Cheyne Bible reading plan + prayer tracker for Calvary Chapel Delta.

## Deploy to Vercel (free, ~10 minutes)

### Step 1 — Get the code on GitHub
1. Go to github.com and sign up for a free account (or log in)
2. Click **New repository** → name it `calvary-daily` → click **Create repository**
3. On your Mac, open Terminal and run:
   ```
   cd ~/Downloads/calvary-daily
   npm install
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/calvary-daily.git
   git push -u origin main
   ```
   (Replace YOUR_USERNAME with your GitHub username)

### Step 2 — Deploy on Vercel
1. Go to vercel.com → sign up free with your GitHub account
2. Click **Add New Project** → select your `calvary-daily` repo
3. Leave all settings as defaults — Vercel auto-detects Vite
4. Click **Deploy**
5. In ~60 seconds you'll get a live URL like `calvary-daily.vercel.app`

### Step 3 — Share it
Send that URL to anyone. They open it on their iPhone, tap
**Share → Add to Home Screen**, and it works like a native app.
Each person's data (readings + prayers) is saved privately on their own device.

### Step 4 — Custom domain (optional, ~5 min)
In Vercel dashboard → your project → Settings → Domains.
Add something like `daily.calvarydelta.com` if you have a domain.

---

## Local development
```
npm install
npm run dev
```
Open http://localhost:5173

## Notes
- The Bible passage viewer calls the Anthropic API — requires an internet connection
- All reading progress and prayer data is stored in localStorage on each user's device
- No backend, no database, no accounts needed
- To add a custom home screen icon, replace `public/icon.png` with a 512×512 PNG
